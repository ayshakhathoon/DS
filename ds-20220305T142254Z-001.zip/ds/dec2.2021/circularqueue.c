#include<stdio.h>
#include<stdlib.h>
void insertatbeg();
void InsertAtEnd();
void InsertBetweentwo();
void deleteatbeg();
void deleteatend();
void deleteatpos();
void exit();
int value,ch,loc1,loc2;
struct Node
{
int data;
struct node *next;
}head=NULL;
void main()
{
do
{
printf("1.Insert at beggining \n 2.Insert at end \n 3.Insert at position \n 4. delete at beggining \n 5. Delete from last \n 6. delete from a position \n 7.exit");
printf("enter your choice");
scanf("%d",&ch);
switch(ch)
{
case 1:
    printf("\nEnter the item which you want to insert\n");
    scanf("%d",&value);
    InsertAtBeggining(value);
    break;
    case 2:
    printf("\nEnter the item which you want to insert\n");
    scanf("%d",&value);
    printf("Enter the positions:\n");
    scanf("%d%d",&loc1,&loc2);
    InsertBetweentwo(value,loc1,loc2);
    break;
    case 3:
    printf("\nEnter the item which you want to insert\n");
    scanf("%d",&value);
    InsertAtEnd(value);
    break;
    case 4:
        deleteatbeg();
        break;
    case 5:

        printf("\nEnter the item which you want to delete\n");
        scanf("%d",&value);
        deleteatpos(value);
        break;
    case 6:
        deleteatend();
        break;
    case 7:
        exit(0);
        break;
    default:
        printf("\nEnter valid choice!!");
}
}
while(ch!=8);
}
void InsertAtBeggining(int value)
{
    struct Node *newNode=malloc(sizeof(struct Node));
    newNode->data=value;
    if(head==NULL)
    {
        head=newNode;
        newNode->next=head;
    }
    else
    {
        struct Node *temp=head;
    while(temp->next!=head)
    {
        temp=temp->next;
    }

    newNode→next=head ;
    head=newNode;
    temp→next=head;

        newNode->next=head;
        head=newNode;
        }
        printf("\n1 node is inserted\n");
    if(head==NULL)
   {
      printf("\nList is Empty\n");
   }
   else
   {
      struct Node *temp = head;
      printf("\n\nList elements are - \n");
      while(temp->next!=NULL)
      {
     printf("%d --->",temp->data);
     temp = temp->next;
      }
      printf("%d --->NULL",temp->data);
   }
}
void InsertAtEnd(int value)
{
   struct Node *newNode=malloc(sizeof(struct Node));
   if(head == NULL)
    head = newNode;
    newNode->next=head;
   else
   {
      struct Node *temp = head;
      while(temp->next != NULL)
      {
        temp = temp->next;
    }
    temp->next = newNode;
    newNode->next=head;
   }
   printf("\nOne node inserted!!!\n");
   if(head == NULL)
   {
      printf("\nList is Empty\n");
   }
   else
   {
      struct Node *temp = head;
      printf("\n\nList elements are - \n");
      while(temp->next != NULL)
      {
     printf("%d --->",temp->data);
     temp = temp->next;
      }
      printf("%d --->NULL",temp->data);
   }
}

void InsertBetweentwo(int value, int loc1, int loc2)
{
   struct Node *newNode=malloc(sizeof(struct Node));
   newNode->data = value;
   if(head == NULL)
   {
      newNode->next = NULL;
      head = newNode;
   }
   else
   {
      struct Node *temp = head;
      while(temp->data != loc1 && temp->data != loc2)
        if(temp->data==NULL)
      {

        temp = temp->next;
      newNode->next = temp->next;
      temp->next = newNode;
      }
   }
   printf("\nOne node inserted!!!\n");
   if(head == NULL)
   {
      printf("\nList is Empty\n");
   }
   else
   {
      struct Node *temp = head;
      printf("\n\nList elements are - \n");
      while(temp->next != NULL)
      {
     printf("%d --->",temp->data);
     temp = temp->next;
      }
      printf("%d --->NULL",temp->data);
   }
}
void deleteatbeg()
{
    if(head==NULL)
    {
        printf("\n list is empty");
    }
    else
    {
        struct Node *temp1,*temp2;
        temp1=head;
        temp2=head;
        if(temp1->next==head)
        {
            head=NULL;
            freeof(temp1);
        }

    }
     while(temp1->next!=head)
     {
     temp2=temp1;
     temp1=temp1->next;
    }
    temp2->next=head;
    freeof(temp2);
    printf("\nOne node inserted!!!\n");
   if(head == NULL)
   {
      printf("\nList is Empty\n");
   }
   else
   {
      struct Node *temp = head;
      printf("\n\nList elements are - \n");
      while(temp->next != NULL)
      {
     printf("%d --->",temp->data);
     temp = temp->next;
      }
      printf("%d --->NULL",temp->data);
   }
}
void deleteatend()
{
    if(head==NULL)
    {
        printf("list is empty");
    }

}
